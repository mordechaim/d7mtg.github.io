var nameresult = document.getElementById("nameresult");


var objectsshuffled = 0;
var returnedFullName;
var normalcyvalue;
var gendervalue;
var religionvalue;
var returnedFullName,
normalcyFirst,
genderFirst,
religionFirst,
normalcyLast,
religionLast,
lastName,
possibleCombinations,
firstName;


function getresult() {


    //10 random numbers



    normalcyFirst = document.querySelector('input[name="normalcy"]:checked').value;
     genderFirst = document.querySelector('input[name="gender"]:checked').value;
     religionFirst = document.querySelector('input[name="religion"]:checked').value;

     normalcyLast = document.querySelector('input[name="normalcy"]:checked').value;
     religionLast = document.querySelector('input[name="religion"]:checked').value;


    //normal


    let allArray = [
        { name: "אבא חייא", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אביגדור", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם אלטר", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם דוב יהודה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם חיים", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם חיים זאב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם יואל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם יודא", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם יושע", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם יעקב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם יצחק", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם מאיר", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם משה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אברהם שלמה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אהרן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אהרן דוב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אהרן יושע", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אהרן מרדכי", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אהרן משה יודא", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אהרן משה ישעי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אהרן נפתלי", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אלטר", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אלי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אלימלך", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אליעזר דוד", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אליעזר מאיר", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אלעזר", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אפרים יואל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "בן ציון אהרן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "בנימין", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "בנציון", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "בעריש", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "בערל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "בצלאל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "בצלאל משה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ברוך", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ברוך מרדכי", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ברוך מרדכי אהרן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "גדלי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "דוד", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "דוד", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "דוד אהרן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "דוד ארי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "דוד לוי", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "הלל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "הערש אלימלך", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "הערשי", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "הערשל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אהרן דוד", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "אהרן יוסף יחיאל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ישראל שמעון", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מענדל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "וואלף", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "זאב דוב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "זושא", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "זלמן לייב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "חיים", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "חיים אלי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "חיים אליעזר", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "חיים הערש", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "חיים מרדכי", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "טובי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "טובי' זאב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יהוסף", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יהושע", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יואל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יואל אהרן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יואל יודא", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יואל ישכר בעריש", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יודא", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יודל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יוחנן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יונה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יוסף", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יוסף אביגדור יקותיאל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יוסף אהרן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יוסף יהושע", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יוסף יונה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יוסף יחזקאל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יושע הערש", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יושע וואלף", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יחזקאל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יחזקאל בנצוין", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יחזקאל דוד", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יחזקאל שרגא דוד", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יעקב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יעקב אלימלך", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יעקב זוסמאן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יעקב חיים", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יעקב יהושע", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יעקב יוחנן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יעקב יוסף", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יצחק", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יצחק", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יצחק אהרן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יצחק אהרן מתתי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יצחק אייזיק", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יצחק וואלף", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יצחק זאב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יצחק יעקב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יצחק מיכאל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יצחק צבי", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יצחק שמואל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יקותיאל אהרן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "יקותיאל דוד אהרן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ירמי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ישעי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ישעי' יחיאל אלטר", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ישעי' יעקב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ישעי' יצחק", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ישראל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ישראל אברהם", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ישראל אהרן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ישראל משה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "לוי יצחק", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "לייבוש", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "לייבל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ליפא", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מאיר זעליג", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מנחם", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מנחם גרשון", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מנחם יודא", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מענדל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מענדל לייב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מענדל מאיר", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מרדכי", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מרדכי אלעזר", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מרדכי דוב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מרדכי לייב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "מרדכי שמואל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה אהרן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה אליעזר אלי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה ארי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה דוד", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה חזקי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה יואל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה יונה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה יוסף", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה יצחק", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה יקותיאל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה מנחם", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה נתן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "משה שמחה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "נחום", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "נחמן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "נחמן משה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "נפתלי הירצקא", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "נפתלי יחזקאל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "נפתלי משה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "סיני", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "עוזר", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "עזריאל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "עזריאל מאיר", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "עזריאל עמרם", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "עקיבא הערש", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "פייוויל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "פישל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "פנחס", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "פסח", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "צבי", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "קלמן", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שאול יחזקאל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שלום", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שלום זושא", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שלום יוסף", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שלום יצחק", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שלמה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שלמה יעקב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שמואל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שמואל בנימין זאב", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שמואל דוד", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שמואל ישעי'", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שמחה", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שמעון", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "שמעון ישראל", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "תנחום", religion: "jewish", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "גדי", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "שלימואל", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "פלוניש׳ל", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "צורישדי", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "פדהצור", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "טרפון", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "בג-בג", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "אביי", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "שאול סאושעל", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "יצחק רגל", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "הילד הפלא לייבי", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "הרב קיימא לן", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "עקיבא פטור", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "צבי קודם זכה", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "איסור ספיידער", religion: "jewish", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "שרה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "הינדי", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "רבקה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "לאה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "גיטי", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "מרים", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "חי", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "חנה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "מירל", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "אסתר צירל", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "אסתר", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "קריינדי", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "בריינדי", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "דבורה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "פייגא", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "עטל", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "מחלי", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "אביגיל", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "רות", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "יהודית", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "ליבא", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "רויזא", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "אביגיל‏", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "בת שבע‏", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "דבורה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "דינה‏", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "חוה‏", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "יוכבד‏", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "מלכה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "תמר", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "בריינדל", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "טשאַרנאַ", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "איידל", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "גיטל", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "הענדל", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "פּערעלע", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "רייזל", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "שיינדל", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "יענטל", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "זיסל", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "זעלדאַ", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "פרומעט", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "גאלדא", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "הדסה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "מאשה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "מנוחה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "נחמה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "פנינה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "שמחה", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "זלאטא", religion: "jewish", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "חלה׳לע", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "קניידל", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "קראנקי", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "שמאנצי", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "זלפה", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "בלהה‏", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "עתליהו‏", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "פועה‏", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "ביילקע", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "צייטל", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "בתיה", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "בינה", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "בונה", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "חשא", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "תרצה", religion: "jewish", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "דזשארדזש", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "דאנאלד", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ראבערט", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "וויליאם", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "בענדזשאמין", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "ריטשארד", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "קריסטאפער", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "קעווין", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "גערי", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "רייען", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "סטיוו", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "סקאט", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "פרענק", religion: "non", gender: "m", weird: "normal", firstOrLast: "first" },
        { name: "המן", religion: "non", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "פרעה", religion: "non", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "אחשוורוש ", religion: "non", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "בלעם", religion: "non", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "נמרוד", religion: "non", gender: "m", weird: "weird", firstOrLast: "first" },
        { name: "דזשעניפער", religion: "non", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "סעלינע", religion: "non", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "עליזאבעט", religion: "non", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "קערען", religion: "non", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "נענסי", religion: "non", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "דזשעסיקע", religion: "non", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "ליסא", religion: "non", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "מארגארעט", religion: "non", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "דאראטהי", religion: "non", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "דעברא", religion: "non", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "מארגארעט", religion: "non", gender: "f", weird: "normal", firstOrLast: "first" },
        { name: "ושתי", religion: "non", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "זרש", religion: "non", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "איזבל", religion: "non", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "אסנת", religion: "non", gender: "f", weird: "weird", firstOrLast: "first" },
        { name: "אבערלאנדער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "אבערלענער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "אייזיקאוויטש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "אינדיג", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "באנדא", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "באש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "בודק", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "בינער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "בירענבוים", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "בערגער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "בערקאוויטש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "בראווער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "בראך", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ברוין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ברייער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ברעטלער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "גאלד", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "גאלדבערגער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "גאלדשטיין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "גלאנצער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "גלויבער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "גליק", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "געטטער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "געלבשטיין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "גראס", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "גרובער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "גרין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "גרינפעלד", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "דאווידאוויטש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "דייטש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "האגער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "האלפערט", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "האפמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "הארטמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "הויער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "הורוביץ", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "היימאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "הירש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "הערמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "וואלדמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "וויזענפעלד", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ווייזער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "וויינבערגער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ווייס", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "וועבער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ווערטהיימער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ווערצבערגער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "זאבעל", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "זיכערמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "זילבערשטיין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "טאבאק", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "טייטלבוים", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "טירנויער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "יאקאב", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "יאקאבאוויטש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "כ\"ץ", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "כהנא", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "לאבין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "לאנדא", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "לאנדוי", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "לייפער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ליכטמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ליכטענשטיין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "לעבאוויטש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "לעפלער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "לעפקאוויטש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מאנדעל", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מאנן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מארקאוויטש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מאשקאוויטש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מויזקאף", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מזרחי", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מיטעלמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מייזליש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מייזעלס", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מילער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מעהרינג", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מענדלאוויטש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "מערץ", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ניימאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "סופר", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "סטראלאוויטש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "סימאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "סנאי", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "סעגעדין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "עסטרייכער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "עפשטיין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "עקשטיין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פאוועל", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פאלאטשעק", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פייערווערגער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פילאפ", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פילאפף", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פיקסלער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פערלמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פערלמוטער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פרידמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פרייזלער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פריינד", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פריעד", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פריעדלענדער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פריעדמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פרענקל", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "צאהלער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "קאהן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "קויפמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "קליין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "קליינבערגער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "קעסלער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "קרויס", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ראבינאוויטש", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ראזענבוים", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ראזענבערג", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ראזענבערגער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ראטה", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "רובין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "רובינפעלד", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "רויזענבוים", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ריבא", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "רייזמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ריספלער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "רעטעק", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "שווארטץ", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "שווארץ", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "שווימער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "שטיין", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "שטיינבערג", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "שיפף", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "שלאגער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "שלעזינגער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "שפיטצער", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "שפילמאן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "וויינגארטן", religion: "jewish", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "אנהענגער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "אפגרינד", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "באקסער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "בויכוויי", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "הייליג", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "טורמע", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "טעסלע", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "טעראר", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "טרויער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "לינדנבוים", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "מאנדלברויט", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "נעכטן", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "נעפּקין", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "סאלאט", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "סייבער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פארטיליגער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פּודינג", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פלעדערמויז", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פלעק", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פראשקעיק", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "צומרינג", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קיגל", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קישנציך", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קלעם", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קעמפּ", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קרימינאל", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קרענק", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "שוויציג", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פלאקס", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קוטשמע", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "בלוט", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "נאקעט", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פאררעטער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "הייזעריג", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "תתחדש", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קאָמפלימעמט", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "מאטכעוויטש", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פעיטשעק", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "נעפּקין", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "נעווערמיינד", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "נעריש", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "מקובצת", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קעמפּ", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "סאלאט", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "טורמע", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פיאַקער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "סטיפנעק", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פראסק", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פינטל", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פלוספעדער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "וועהרמאכט", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "בריעף", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "טעראר", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "דארפסמאן", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פילאדעלפיע", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פאטענציאל", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "ציפ", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "מארקעטינג", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "דעקל", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "מאמאנט", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "ענדרויד", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "סייבער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "מעגליכקייט", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "שטיל", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "ראסיסט זי״ע", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "אקוראט", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "טראצדעם", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קירוב", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "חירוף", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "גייקאו", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קיגל", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "פלאטפארמע", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "מאראסט", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קלעם", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "טרויער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "קרעמלין", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "טראפ", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "נעכטן", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "אייוועלט", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "אינטשמעסטער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "בעדפארד", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "שליסלהאלטער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "טריביון", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "רובריק", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "גרימצארן", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "גראגער", religion: "jewish", gender: "n/a", weird: "weird", firstOrLast: "last" },
        { name: "סמיט", religion: "non", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "דזשאנסאן", religion: "non", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "וויליאמס", religion: "non", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "דעוויס", religion: "non", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ראדריגעז", religion: "non", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "לאפעז", religion: "non", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "ווילסאן", religion: "non", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "אנדערסאן", religion: "non", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "פערעז", religion: "non", gender: "n/a", weird: "normal", firstOrLast: "last" },
        { name: "טראמפאבליקען", religion: "non", gender: "n/a", weird: "weird", firstOrLast: "last" },

        { name: "ווייט", religion: "non", gender: "n/a", weird: "normal", firstOrLast: "last" }

    ]



    let firstNameArray = allArray.filter(name => {
        return name.firstOrLast == "first"
    })
    let lastNameArray = allArray.filter(name => {
        return name.firstOrLast == "last"
    })




    let filteredFirst = firstNameArray.filter(name => {
        return religionFirst.includes(name.religion) && genderFirst.includes(name.gender) && normalcyFirst.includes(name.weird)
    })

    let filteredLast = lastNameArray.filter(name => {
        return religionLast.includes(name.religion) && normalcyLast.includes(name.weird)
    })

    let firstLength=filteredFirst.length
    let lastLength=filteredLast.length

     possibleCombinations=firstLength*lastLength

     firstName=filteredFirst[Math.floor(Math.random()*firstLength)]
     lastName=filteredLast[Math.floor(Math.random()*lastLength)]







      returnedFullName = firstName.name + " " + lastName.name;




    //momemt of truth
    nameresult.innerHTML = returnedFullName;

    //copy to clipboard





  objectsshuffled++;

    setTimeout(() => {
        document.getElementById("go").blur();
    }, 100);

bottomtext();


}

addEventListener("keydown", function (e) {
    if (e.keyCode === 13) {

        document.getElementById("go").focus();


    }
});


//close buttons
function closecustomization() {



    document.getElementById("outercustomization").style.display = "none";
    document.getElementById("showsettings").innerHTML = '<p onclick="opencustomization()">Show settings</p>';
}


function opencustomization() {

    document.getElementById("outercustomization").style.display = "block";
    document.getElementById("showsettings").innerHTML = '<p onclick="closecustomization()">Hide settings</p>';


}

// Make the DIV element draggable:
dragElement(document.getElementById("outercustomization"));

function dragElement(elmnt) {
    var pos1 = 0,
        pos2 = 0,
        pos3 = 0,
        pos4 = 0;
    if (document.getElementById(elmnt.id + "header")) {
        // if present, the header is where you move the DIV from:
        document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
    } else {
        // otherwise, move the DIV from anywhere inside the DIV:
        elmnt.onmousedown = dragMouseDown;
    }

    function dragMouseDown(e) {
        e = e || window.event;
        e.preventDefault();
        // get the mouse cursor position at startup:
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        // call a function whenever the cursor moves:
        document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
        e = e || window.event;
        e.preventDefault();
        // calculate the new cursor position:
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        // set the element's new position:
        elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
        elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
    }

    function closeDragElement() {
        // stop moving when mouse button is released:
        document.onmouseup = null;
        document.onmousemove = null;
    }
}

function bottomtext() {

  //how many clicks
  var sezoedobjectsshuffled = "0000" + objectsshuffled;
  var length = sezoedobjectsshuffled.length;
  var calculatedfour = length - 5;
  var returnedobjectsshuffled = sezoedobjectsshuffled.substring(calculatedfour, length);

//return clicks
  document.getElementById('objectsshuffled').innerHTML = returnedobjectsshuffled;

  //binary conversion
  //var output = document.getElementById("binary");
  //var input = returnedFullName;
  //output.innerHTML = "";
  //for (var i = 0; i < input.length; i++) {
  //    output.innerHTML += input[i].charCodeAt(0).toString(2) + " ";
  //}
//char code
//  var outputC = document.getElementById("charcode");
//  var inputC = returnedFullName;
//  outputC.innerHTML = "";
//  for (var i = 0; i < inputC.length; i++) {
//      outputC.innerHTML += inputC[i].charCodeAt(0) + " ";

//  }


document.getElementById('currentsettings').innerHTML = `NORMALCY: ${normalcyFirst.toUpperCase()=="RANDOMNORMALWEIRD"?"RANDOM":normalcyFirst.toUpperCase()} // GENDER: ${genderFirst.toUpperCase()=="M"?"MALE": genderFirst.toUpperCase()=="F"?"FEMALE":"RANDOM"} // RELIGION: ${religionFirst.toUpperCase()=="JEWISH"?"JEWISH": religionFirst.toUpperCase()=="NON"?"NONJEWISH":"RANDOM"}`
document.getElementById('currentresults').innerHTML = `NORMALCY: ${firstName.weird.toUpperCase()} // GENDER: ${firstName.gender.toUpperCase()=="M"?"MALE": firstName.gender.toUpperCase()=="F"?"FEMALE":"ERROR"} // RELIGION: ${firstName.religion.toUpperCase()=="JEWISH"?"JEWISH": firstName.religion.toUpperCase()=="NON"?"NONJEWISH":"ERROR"}`


 document.getElementById('possible').innerHTML = possibleCombinations;



}
