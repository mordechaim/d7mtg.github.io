var nameresult = document.getElementById("nameresult");


var objectsshuffled = 00000;
var returnedFullName;
var normalcyvalue;
var gendervalue;
var religionvalue;
var returnedFullName,
normalcyFirst,
genderFirst,
religionFirst,
normalcyLast,
religionLast,
lastName,
possibleCombinations,
firstName,
mismatch;


function getresult() {




document.getElementById("go").className = "activeGo";



 document.getElementById("copied").style.display = "none";
    normalcyFirst = document.querySelector('input[name="normalcy"]:checked').value;
    genderFirst = document.querySelector('input[name="gender"]:checked').value;
    religionFirst = document.querySelector('input[name="religion"]:checked').value;
    normalcyLast = document.querySelector('input[name="normalcy"]:checked').value;
    religionLast = document.querySelector('input[name="religion"]:checked').value;
	mismatch = document.querySelector('input[name="mismatch"]').checked;

    fetch("https://shuffle-names.herokuapp.com/", {
        method: "POST",
        body: JSON.stringify({
            "normalcyFirst": normalcyFirst,
            "genderFirst": genderFirst,
            "religionFirst": religionFirst,
            "normalcyLast": normalcyLast,
            "religionLast": religionLast,
			"mismatch": mismatch
        }),
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })
        .then(response => response.json())    
        .then(json => main(json));

    const main = (obj) => {

        firstName = obj.firstName
        lastName = obj.lastName

        returnedFullName = firstName.name + " " + lastName.name;

        //momemt of truth


        
        
			setTimeout(function(){
				nameresult.innerHTML = returnedFullName;
				objectsshuffled++;
				bottomtext();
				document.getElementById("go").className = "inactiveGo";

			}, Math.floor(Math.random() * 800)+500);

        	    


        
    }
}

function newpossible(){

normalcyFirst = document.querySelector('input[name="normalcy"]:checked').value;
    genderFirst = document.querySelector('input[name="gender"]:checked').value;
    religionFirst = document.querySelector('input[name="religion"]:checked').value;
    normalcyLast = document.querySelector('input[name="normalcy"]:checked').value;
    religionLast = document.querySelector('input[name="religion"]:checked').value;
	mismatch = document.querySelector('input[name="mismatch"]').checked;

fetch("https://shuffle-names.herokuapp.com/poss", {
        method: "POST",
        body: JSON.stringify({
            "normalcyFirst": normalcyFirst,
            "genderFirst": genderFirst,
            "religionFirst": religionFirst,
            "normalcyLast": normalcyLast,
            "religionLast": religionLast,
			"mismatch": mismatch
        }),
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })
        .then(response => response.json())
        .then(json => main(json));

 		const main = (obj) => {
			possibleCombinations = obj
			document.getElementById('possiblecombinations').innerHTML = possibleCombinations.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
			document.getElementById('possiblecombinationstwo').innerHTML = possibleCombinations.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");


			if(mismatch == true){
				mismatchcheckbox.innerHTML = '<i class="far fa-check"></i>';

			} else {
				mismatchcheckbox.innerHTML = '<i class="far fa-fw"></i>';
			}


			if (document.querySelector('input[name="religion"]:checked').value == "non" || document.querySelector('input[name="religion"]:checked').value == "randomjewishnon"){
				document.getElementById("weird").disabled = true;  
				document.getElementById("randomnormalweird").disabled = true;  

				document.getElementById('normal').checked = true;

			} else {
				document.getElementById("weird").disabled = false;  
				document.getElementById("randomnormalweird").disabled = false;  
			}



			if (document.querySelector('input[name="normalcy"]:checked').value == "randomnormalweird" || document.querySelector('input[name="religion"]:checked').value == "randomjewishnon"){
								

					document.getElementById("mismatch").disabled = false;  



			} else {
				
					document.getElementById("mismatch").disabled = true;  
					document.getElementById("mismatch").checked = false;  


				mismatchcheckbox.innerHTML = '<i class="far fa-ban"></i>';




			}

bottomtext();
	
}

    



}

addEventListener("keydown", function (e) {
    if (e.keyCode === 13) {

getresult();

    }
});





//close buttons
function closecustomization() {

          


    document.getElementById("outercustomization").className = "settingshidden"; 
    document.getElementById("showsettings").innerHTML = '<span onclick="opencustomization()">CHANGE SETTINGS</span>';
}


function opencustomization() {

    document.getElementById("outercustomization").className = "settingshown"; 

    document.getElementById("showsettings").innerHTML = '<span onclick="closecustomization()">CLOSE SETTINGS PANE</span>';


}


init();

// Make the DIV element draggable:
dragElement(document.getElementById("outercustomization"));



function dragElement(elmnt) {
    var pos1 = 0,
        pos2 = 0,
        pos3 = 0,
        pos4 = 0;
    if (document.getElementById(elmnt.id + "header")) {
        // if present, the header is where you move the DIV from:
        document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
    } else {
        // otherwise, move the DIV from anywhere inside the DIV:
        elmnt.onmousedown = dragMouseDown;
    }

    function dragMouseDown(e) {
        e = e || window.event;
        e.preventDefault();
        // get the mouse cursor position at startup:
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        // call a function whenever the cursor moves:
        document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
        e = e || window.event;
        e.preventDefault();
        // calculate the new cursor position:
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        // set the element's new position:
        elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
        elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
    }

    function closeDragElement() {
        // stop moving when mouse button is released:
        document.onmouseup = null;
        document.onmousemove = null;
    }
}
//start touch
function touchHandler(event) {
    var touch = event.changedTouches[0];

    var simulatedEvent = document.createEvent("MouseEvent");
        simulatedEvent.initMouseEvent({
        touchstart: "mousedown",
        touchmove: "mousemove",
        touchend: "mouseup"
    }[event.type], true, true, window, 1,
        touch.screenX, touch.screenY,
        touch.clientX, touch.clientY, false,
        false, false, false, 0, null);

    touch.target.dispatchEvent(simulatedEvent);
    event.touchmove.preventDefault();
}

function init() {
    document.addEventListener("touchstart", touchHandler, true);
    document.addEventListener("touchmove", touchHandler, true);
    document.addEventListener("touchend", touchHandler, true);
    document.addEventListener("touchcancel", touchHandler, true);
}
//end touch


function bottomtext() {

    document.getElementById('mismatchbottom').innerHTML = mismatch.toString().toUpperCase();

  //how many clicks
  var sezoedobjectsshuffled = "0000" + objectsshuffled;
  var length = sezoedobjectsshuffled.length;
  var calculatedfour = length - 5;
  var returnedobjectsshuffled = sezoedobjectsshuffled.substring(calculatedfour, length);

//return clicks


  document.getElementById('objectsshuffled').innerHTML = returnedobjectsshuffled;

document.getElementById('currentsettings').innerHTML = `NORMALCY: ${normalcyFirst.toUpperCase()=="RANDOMNORMALWEIRD"?"RANDOM":normalcyFirst.toUpperCase()} // GENDER: ${genderFirst.toUpperCase()=="M"?"MALE": genderFirst.toUpperCase()=="F"?"FEMALE":"RANDOM"} // RELIGION: ${religionFirst.toUpperCase()=="JEWISH"?"JEWISH": religionFirst.toUpperCase()=="NON"?"NONJEWISH":"RANDOM"}`
document.getElementById('currentresults').innerHTML = `NORMALCY: ${firstName.weird.toUpperCase()} // GENDER: ${firstName.gender.toUpperCase()=="M"?"MALE": firstName.gender.toUpperCase()=="F"?"FEMALE":"ERROR"} // RELIGION: ${firstName.religion.toUpperCase()=="JEWISH"?"JEWISH": firstName.religion.toUpperCase()=="NON"?"NONJEWISH":"ERROR"}`;





}

//clipboard
 var clipboard = new ClipboardJS('.btn');

      clipboard.on('success', function (e) {
        console.log(e);
      });

      clipboard.on('error', function (e) {
        console.log(e);
      });


//add possible
var checkboxes = document.querySelectorAll("input");

for (var i = 0; i < checkboxes.length; i++){
									  
		checkboxes[i].addEventListener("change", newpossible);						  
}
									  
									